from abc import ABCMeta, abstractmethod

class IPojazd:

    __metaclass__ = ABCMeta

    @abstractmethod
    def spalanie(self, spal, odl):raise NotImplementedError

    @abstractmethod
    def kosztprzejazdu(self,spal,odl,cena_l):raise NotImplementedError