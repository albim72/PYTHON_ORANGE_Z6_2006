from abc import ABCMeta, abstractmethod

class ISamochod:

    __metaclass__ = ABCMeta

    @abstractmethod
    def opispojazdu(self,marka,model,poj,rocznik):raise NotImplementedError

    @abstractmethod
    def daneeksploatacyjne(self,przebieg,databadania,stan):raise NotImplementedError