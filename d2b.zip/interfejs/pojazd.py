from IPojazd import IPojazd
from ISamochod import ISamochod

class Pojazd(IPojazd,ISamochod):

    def spalanie(self, spal, odl):
        return spal*100/odl

    def kosztprzejazdu(self, spal, odl, cena_l):
        return self.spalanie(spal,odl)*(odl/100)*cena_l

    def opispojazdu(self, marka, model, poj, rocznik):
        return f"dane pojazdu -> marka: {marka}, model: {model}, pojemność: {poj}, rocznik: {rocznik}."

    def daneeksploatacyjne(self, przebieg, databadania, stan):
        return f"dane eksploatacyjne -> przebieg: {przebieg} km, data badania: {databadania}, " \
               f"stan techniczny: {stan}"

