from pojazd import Pojazd

p1 = Pojazd()

s  =float(input("Podaj liczbę spalonych litrów na trasie: "))
o = float(input("Podaj liczbę kilometrów: "))
c = float(input("Podaj cenę paliwa [litr]: "))

print(f"spalanie na 100km: {p1.spalanie(s,o):.2f}")
print(f"koszt przejzadu na trasie: {o} km wynosi: {p1.kosztprzejazdu(s,o,c):.2f} zł")

#stórz qusiinterfejs ISamochod -> zadeklaruj metodę abs -> opispojazdu(marka,model,poj,rocznik)
#oraz drugą metodę abst -> daneeksploatacyjne(przebieg,databadania,stan)
#dziedzicz klasę ISamochod przez Pojzad i zaimplementuj obie metody (mają wy świetlać zadane wartości)
# a następnie użyj je dla instancji p1 (w main.py)
print(p1.opispojazdu("Peugeot","508",2.4,2019))
print(p1.daneeksploatacyjne(89500,"2023-01-12","bezwypadkowy, badania ASO"))
