class ContextManager:

    def __init__(self):
        print("wywołanie metody predefiniowanej init()")

    def __enter__(self):
        print("wywołanie metody predefiniowanej enter()")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        print("wywołanie metody predefiniowanej exit()")

with ContextManager() as manager:
    print("tutaj jest blok wykonawczy.....")