import logging

class OldResitor:

    def __init__(self,ohms):
        self._ohms = ohms

    def get_ohms(self):
        return self._ohms

    def set_ohms(self,ohms):
        self._ohms = ohms


r0 = OldResitor(50e3)
print(f"oporność przed zmianą: {r0.get_ohms()} omów")

r0.set_ohms(10e3)
print(f"oporność po zmianie: {r0.get_ohms()} omów")


class Resistor:

    def __init__(self, ohms):
        self.ohms = ohms
        self.voltage = 0
        self.current = 0

r1 = Resistor(50e3)
r1.ohms = 10e3
print(f"układ E: oporność: {r1.ohms} omów, napięcie: {r1.voltage} V,"
      f" natężenie: {r1.current} A")


class VoltageResistance(Resistor):
    def __init__(self, ohms):
        super().__init__(ohms)
        self._voltage = 0

    @property #getter
    def voltage(self):
        return self._voltage

    @voltage.setter #setter
    def voltage(self,voltage):
        self._voltage = voltage
        self.current = self._voltage/self.ohms

r2 = VoltageResistance(1e3)
print(f'wartość natężenie prądu przed zmianą: {r2.current:.2f} amperów')
r2.voltage = 10
print(f'wartość natężenie prądu po zmianie: {r2.current:.2f} amperów')

class BResistance(Resistor):

    def __init__(self,ohms):
        super().__init__(ohms)

    @property
    def ohms(self):
        return self._ohms

    @ohms.setter
    def ohms(self,ohms):
        if ohms <= 0:
            raise ValueError(f'Wartość rezystancji: {ohms}, musi być większa od 0')
        self._ohms = ohms

try:
    r3 = BResistance(1e3)
    r3.ohms = 0
except:
    logging.exception('Wystąpił błąd w kodzie wywołującym....')
else:
    assert True

