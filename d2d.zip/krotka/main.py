#dzidziczenie typów immutable

class PositiveNumberTuple(tuple):

    def __new__(cls, *numbers):
        skipped_values_count = 0
        positivenumbers = []

        for x in numbers:
            if x>=0:
                positivenumbers.append(x)
            else:
                skipped_values_count += 1

        instance = super().__new__(cls,tuple(positivenumbers))
        instance.skipped_values_count = skipped_values_count

        return instance


pos_int_tuple = PositiveNumberTuple(-34,9,0,78,-44,667,-9,1,10,5)
print(pos_int_tuple)
print(type(pos_int_tuple))
print(pos_int_tuple.skipped_values_count)