pytanie= input("Czy Ziemia jest płaska? chcesz znać odpowiedź? (t/n): ")

if pytanie.lower() == "t":
    required = True
else:
    required = False


def odpowiedz(self):
    return "Tak! Ziemia jest płaska."

def odpowiedz_new(self):
    return "Nie! Ziemia jest okrągła."

class SednoOdpowiedzi(type):

    def __init__(cls,clsname,superclasses, attribdict):
        if required:
            if clsname == "Kopernik":
                cls.odpowiedz = odpowiedz_new
            else:
                cls.odpowiedz = odpowiedz

class Arystoteles(metaclass=SednoOdpowiedzi):
    pass
class Platon(metaclass=SednoOdpowiedzi):
    pass

class SwTomasz(metaclass=SednoOdpowiedzi):
    pass

class Kopernik(metaclass=SednoOdpowiedzi):
    pass

fil1 = Arystoteles()
fil2 = Platon()
fil3 = SwTomasz()
fil4 = Kopernik()


print(f"Arystoteles mówi: {fil1.odpowiedz()}")
print(f"Platon mówi: {fil2.odpowiedz()}")
print(f"Święty Tomasz mówi: {fil3.odpowiedz()}")
print(f"Kopernik mówi: {fil4.odpowiedz()}")

#nie zmieniając konstrukcji programu spraw aby Kopernik mówił: Ziemia jest okrągła!
