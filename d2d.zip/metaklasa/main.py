class MojaMeta(type):

    def __new__(cls,classname,superclasses,attributedict):
        print(f"nazwa klasy: {classname}")
        print(f"dziedziczone klasy: {superclasses}")
        print(f"zbiór atrybutów: {attributedict}")
        return type.__new__(cls,classname,superclasses,attributedict)

class Pusta:
    pass

class Pierwsza(Pusta,metaclass=MojaMeta):
    pass

class Druga(Pierwsza):
    pass

class Ekstra(Druga):
    pass


p = Pusta()
a = Pierwsza()
b = Druga()
c = Ekstra()