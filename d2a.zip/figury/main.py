from prostokat import Prostokat
from trojkat import Trojkat
from trapez import Trapez
from kolo import  Kolo

pr = Prostokat(3.6,5.8)
print(f"pole prostokąta wynosi: {pr.policz_pole():.2f}")

tr = Trojkat(5.5,8.9)
print(f"pole trójkąta wynosi: {tr.policz_pole():.2f}")

trp = Trapez(4.5,2.3,3.9)
print(f"pole trapezu wynosi: {trp.policz_pole():.2f}")

#stwórz klasę Kolo(Figura) o promieniu a.
#policz pole koła dla a=5.5
#pole koła math.pi*a**2

kl = Kolo(5.5)
print(f"pole koła wynosi: {kl.policz_pole():.2f}")