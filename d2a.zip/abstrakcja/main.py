from abc import ABC, abstractmethod

class Prototyp(ABC):

    def __init__(self,x):
        self.x = x

    def info(self):
        return "to jest metoda nieabstrakcyjna klasy abstrakcyjnej"

    @abstractmethod
    def policz(self):
        pass

    @abstractmethod
    def policz_x(self):
        return self.x * 5



class Second(Prototyp):

    def __init__(self,x,y):
        Prototyp.__init__(self,x)
        self.y = y

    def policz(self):
        return 1001

    def policz_x(self):
        return super().policz_x() + self.y*3


s = Second(4,7)
print(f"wynik funkcji policz(): {s.policz()}")
print(f"wynik funkcji policz_x(): {s.policz_x()}")
