def prac(funkcja):
    def wrapper(self):
        if funkcja(self) == False:
            return "NIE"
        else:
            return "TAK"

    return wrapper