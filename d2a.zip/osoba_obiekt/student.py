from pracownik import Pracownik
from sport import Sport
from ekstra import Ekstra
from wrapps import prac


class Student(Pracownik, Sport, Ekstra):

    def __init__(self,imie,nazwisko,wiek,waga,wzrost,nr_studenta,kierunek,rok_ukon,
                 firma="",stanowisko="",latapracy="",wynagrodenie="",dyscyplina="", lataupr="",best_wynik=""):
        Pracownik.__init__(self,imie,nazwisko,wiek,waga,wzrost,firma,stanowisko,latapracy,wynagrodenie)
        Sport.__init__(self,dyscyplina, lataupr,best_wynik)
        self.nr_studenta = nr_studenta
        self.kierunek = kierunek
        self.rok_ukon = rok_ukon

    def print_student(self):
        print(f"student nr: {self.nr_studenta}, kierunek: {self.kierunek}, rok ukończenia studiów: {self.rok_ukon}")

    @prac
    def czypracownik(self) ->  bool:
        return self.firma != ""
