from osoba import Osoba
from pracownik import Pracownik
from student import Student

p1 = Osoba("Olga","Kot",33,61,176)
print(f"kolor oczu: {p1.kolor_oczu}")
p1.print_osoba()
print(f"wiek za 10 lat: {p1.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {p1.czypracownik()}")
print(f"bmi ciała wynosi: {p1.bmi():.2f}, opis: {p1.opisbmi()}")
print(f"zapotrzebowanie energetyczne: {p1.policzppm('k'):.2f} kcal")

#napisz funckję wrapper, kótra będzie sprawdzała zwrotę False albo True z funkcji czypracownik i wstawiała wartość
#TRUE -> TAK, False -> NIE
print("_____________________________________________________")
p2 = Osoba("Roman","Nowak",50,102,173)
p2.kolor_oczu = "niebieskie"
print(f"kolor oczu: {p2.kolor_oczu}")
p2.print_osoba()
print(f"wiek za 10 lat: {p2.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {p2.czypracownik()}")

print("_____________________________________________________")
e1 = Pracownik("Anna","Kowal",29,54,166,"ABC","księgowa",4,5600)
print(f"kolor oczu: {e1.kolor_oczu}")
e1.print_osoba()
e1.print_pracownik()
print(f"wiek za 10 lat: {e1.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {e1.czypracownik()}")

print("_____________________________________________________")

s1 = Student("Olaf","Kos",22,77,178,53455,"budownictwo",2023)
s1.print_osoba()
s1.print_student()
print(f"wiek za 10 lat: {s1.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {s1.czypracownik()}")

#stwórz obiekty: student - pracownik, student - sportowiec
print("_____________________________________________________")
s2 = Student("Olga","Kowal",21,56,170,85676,"informatyka",2024,"XYZ","Junior Developer",1,3200)
s2.print_osoba()
s2.print_pracownik()
s2.print_student()
print(f"wiek za 10 lat: {s2.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {s2.czypracownik()}")

print("_____________________________________________________")
s3 = Student("Robert","Nowak",22,71,172,75343,"informatyka",2023,dyscyplina="biegi ultra",
             lataupr=5,best_wynik="102km  18h 45min 12s")
s3.print_osoba()
s3.print_student()
s3.infosport()
print(f"wiek za 10 lat: {s3.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {s3.czypracownik()}")
print(f"bmi ciała wynosi: {s1.bmi():.2f}, opis: {s1.opisbmi()}")