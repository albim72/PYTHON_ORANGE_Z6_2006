from osoba import Osoba
from wrapps import prac

class Pracownik(Osoba):

    def __init__(self,imie,nazwisko,wiek,waga,wzrost,firma,stanowisko,latapracy,wynagrodenie):
        super().__init__(imie,nazwisko,wiek,waga,wzrost)
        self.firma = firma
        self.stanowisko = stanowisko
        self.latapracy = latapracy
        self.wynagrodzenie = wynagrodenie

    def print_pracownik(self):
        print(f"dane pracownika -> firma: {self.firma}, stanowisko pracy: {self.stanowisko},"
              f" lata pracy: {self.latapracy}, wynagrodzenie: {self.wynagrodzenie}")
    @prac
    def czypracownik(self) ->  bool:
        return True


