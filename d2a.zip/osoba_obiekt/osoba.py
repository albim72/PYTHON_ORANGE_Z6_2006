from wrapps import prac

class Osoba:

    kolor_oczu = "brązowe"

    #opis stanu - konstruktor klasy
    def __init__(self,imie,nazwisko,wiek,waga,wzrost):
        self.imie = imie
        self.nazwisko = nazwisko
        self.wiek = wiek
        self.waga = waga
        self.wzrost = wzrost
        self.info()


    #opis zachowania - funkcje klasy -> metody

    def info(self):
        print("tworzenie nowej instancji klasy Osoba")

    def print_osoba(self):
        print(f"osoba -> imię: {self.imie}, nazwisko: {self.nazwisko}, wiek: {self.wiek} lat, "
              f"wzrost: {self.wzrost} cm, waga: {self.waga} kg")

    def wiekza10lat(self) -> int:
        return self.wiek + 10

    @prac
    def czypracownik(self) ->  bool:
        return False

    def bmi(self):
        return self.waga/(self.wzrost/100)**2

    def opisbmi(self):
        if self.bmi() < 18.5:
            return "niedowaga"
        elif self.bmi() <= 25:
            return "waga standardowa"
        elif self.bmi() <= 30:
            return "nadwaha"
        else:
            return "otyłość"

    def policzppm(self,plec):
        if plec.lower() == "k":
            return 655.1 + 9.563*self.waga + 1.85*self.wzrost - 4.676*self.wiek
        elif plec.lower() == "m":
            return 66.5 + 13.75 * self.waga + 5.003 * self.wzrost - 6.775 * self.wiek
        else:
            return "błędne oznaczenie płci...."

