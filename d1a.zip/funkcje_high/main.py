def filrowanie(tablica,test):
    dodane = []
    for element in tablica:
        if(test(element)):
            dodane.append(element)
    return dodane


def test_liczby(liczba):
    return liczba >= 10

dane_testowe = [1,5,16,8,11,10,2,3,34,19]
print(filrowanie(dane_testowe,test_liczby))

def mapowanie(tablica,transformacja):
    mapowane = []
    for element in tablica:
        mapowane.append(transformacja(element))
    return mapowane


def transformacja_dodaj_w(liczba):
    return liczba +22

print(mapowanie(dane_testowe,transformacja_dodaj_w))


