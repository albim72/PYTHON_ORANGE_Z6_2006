import time

def pomiarczasu(funkcja):
    def wrapper():
        starttime = time.perf_counter()
        funkcja()
        endtime = time.perf_counter()
        print(f"czas wykonania funckji: {endtime-starttime} s")
    return  wrapper


def opoznienie(funkcja):
    def wrapper():
        time.sleep(8)
        return funkcja()
    return  wrapper

def nazwaf(funkcja):
    def wrapper():
        print(f"wywołana funkcja: {funkcja.__name__}")
        funkcja()
    return wrapper


# @nazwaf
# def mapowanielisty_n():
#     sum([i**2 for i in range(1000000)])

@nazwaf
@opoznienie
@pomiarczasu

def mapowanielisty():
    sum([i**2 for i in range(1000000)])

#mapowanielisty_n()
mapowanielisty()