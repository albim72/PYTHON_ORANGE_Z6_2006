miasto = "Lublin"
wiek = 45
imie = "Janek"

dane = "Dane klienta -> miasto: {}, wiek: {}, imie: {}"
print(dane.format(miasto,wiek,imie))

dane = "Dane klienta -> imię: {2}, wiek: {1}, miasto: {0}"
print(dane.format(miasto,wiek,imie))

#f-string
print(f"Dane studenta -> imię:{imie}, wiek: {wiek},miasto: {miasto}")

id = "mw"
value = 56.4567

formatowanie = '%-30s = %.2f' %(id,value)
print(formatowanie)

owoce = [
    ('truskawka',8.33),
    ('malina',17.5),
    ('jabłko',4.55),
    ('czereśnia',12.00),
    ('banan',4.99)
]
print("____________________________________")
for i,(nazwa,cena) in enumerate(owoce):
    print('#%d: %-10s = %.2f zł' %(i,nazwa,cena))

print("____________________________________")
for i,(nazwa,cena) in enumerate(owoce):
    print('#%d: %-10s = %.2f zł' %(
        i+1,
        nazwa.title(),
        round(cena,1)
    ))