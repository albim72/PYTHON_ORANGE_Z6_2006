import math

f = 100

def fx(n):
    return math.exp(n)*math.sqrt(n)

def policz(a,b,y,x=1):
    global f
    f = (a+b)*x - y + f + fx(b)
    return f

print(policz(23,7,3,8))
print(f)
print(policz(14,7,2))


x = lambda a: math.sqrt(a)+a
print(x(24))

def ax(a):
    return math.sqrt(a)+a

print(ax(9))

y = lambda a,b,c=2:math.sqrt(a)+b*c
print(y(2,1,5.5))
print(y(2,1))

def multi(n):
    return lambda a:a*n

print(multi(56)(8))

liczby = [1,4,3,6,7,8,12,45,9,11,66,34,27]

#utwórz nową listę parzyste[] przekazując do niej tylko wartości parzyste z listy liczby

parzyste = list(filter(lambda x:(x%2==0),liczby))
print(parzyste)

#utwórz listę cube[] przekzaując do niej wszystkie wartości z listy liczby podniesione do sześcianu

cube = list(map(lambda x:x**3,liczby))
print(cube)

