def pozdrowienia(imie):
    return f'Witaj {imie}'

def osoba(funkcja,imie):
    return funkcja(imie)

print(osoba(pozdrowienia,"Olga"))

def gratulacje(jesli):
    def gratuluj():
        return "gratulacje zdanego egzaminu!"
    def szkoda():
        return "Przykro mi, ale następnym razem będzie lepiej!"
    if jesli == "tak":
        return gratuluj
    else:
        return szkoda

print(gratulacje("tak")())
print(gratulacje("nie")())

def startstop(funkcja):
    def wrapper():
        print("startowanie procesu.....")
        funkcja()
        print("kończenie procesu")
    return wrapper

def zawijanie():
    print("zawijanie czekoladek w sreberka")

startstop(zawijanie)()

@startstop
def dmuchanie():
    print("dmuchanie baloników na imprezę")


dmuchanie()