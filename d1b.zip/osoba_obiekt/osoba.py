from wrapps import prac

class Osoba:

    kolor_oczu = "brązowe"

    #opis stanu - konstruktor klasy
    def __init__(self,imie,nazwisko,wiek,waga,wzrost):
        self.imie = imie
        self.nazwisko = nazwisko
        self.wiek = wiek
        self.waga = waga
        self.wzrost = wzrost
        self.info()


    #opis zachowania - funkcje klasy -> metody

    def info(self):
        print("tworzenie nowej instancji klasy Osoba")

    def print_osoba(self):
        print(f"osoba -> imię: {self.imie}, nazwisko: {self.nazwisko}, wiek: {self.wiek} lat, "
              f"wzrost: {self.wzrost} cm, waga: {self.waga} kg")

    def wiekza10lat(self) -> int:
        return self.wiek + 10

    @prac
    def czypracownik(self) ->  bool:
        return False
