from osoba import Osoba
from pracownik import Pracownik

p1 = Osoba("Olga","Kot",33,63,176)
print(f"kolor oczu: {p1.kolor_oczu}")
p1.print_osoba()
print(f"wiek za 10 lat: {p1.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {p1.czypracownik()}")

#napisz funckję wrapper, kótra będzie sprawdzała zwrotę False albo True z funkcji czypracownik i wstawiała wartość
#TRUE -> TAK, False -> NIE
print("_____________________________________________________")
p2 = Osoba("Roman","Nowak",50,102,173)
p2.kolor_oczu = "niebieskie"
print(f"kolor oczu: {p2.kolor_oczu}")
p2.print_osoba()
print(f"wiek za 10 lat: {p2.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {p2.czypracownik()}")

print("_____________________________________________________")
e1 = Pracownik("Anna","Kowal",29,54,166,"ABC","księgowa",4,5600)
print(f"kolor oczu: {e1.kolor_oczu}")
e1.print_osoba()
e1.print_pracownik()
print(f"wiek za 10 lat: {e1.wiekza10lat()} lat/a")
print(f"czy osoba jest pracownikiem? {e1.czypracownik()}")