class Ekstra:
    pass