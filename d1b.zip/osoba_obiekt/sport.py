class Sport:

    def __init__(self,dyscyplina, lataupr,best_wynik):
        self.dysycyplina = dyscyplina
        self.lataupr = lataupr
        self.best_wynik = best_wynik

    def infosport(self):
        print(f"dyscyplina: {self.dysycyplina}, czas uprawiania: {self.lataupr},"
              f" życiówka: {self}")
