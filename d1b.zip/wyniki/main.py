liczby = [45,89,99,12,34,58,101,2,45,87,12,15,10,68,99,23,45,18,91,67]

def statystyki(lista):
    minimum = min(lista)
    maksimum = max(lista)
    srednia = sum(lista)/len(lista)
    rozstep = maksimum - minimum
    return minimum, maksimum, srednia, rozstep

wynik = statystyki(liczby)
print(wynik)
mini,maxi,srd,roz = statystyki(liczby)
print(f"maksimum: {maxi}, minimum: {mini}, rozstęp: {roz}, średnia wartość: {srd}")

def get_srednia_odchyl(w):
    avg = sum(w)/len(w)
    skala = [x/avg for x in w]
    skala.sort(reverse=True)
    return skala

najmniejsza, *posrodku, najwieksza = get_srednia_odchyl(liczby)
print(f'Najmniejsza wartość: {najmniejsza: 0.0%}')
print(f'Największa wartość: {najwieksza: 0.0%}')