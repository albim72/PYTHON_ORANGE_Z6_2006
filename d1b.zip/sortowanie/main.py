slownik_old =  ['samolot','samochod','marchewka','mecz','miecz','Mieczysław','Roman',
            'rolka','abakus','zenit','piorun','_a']

def mojesortowanie_old(a):
    # for i,w in enumerate(slownik_old):
    #     slownik_old[i] = w.lower()
    for _ in range(len(a)):
        for i in range(1,len(a)):
            if a[i].lower() < a[i-1].lower():
                temp = a[i]
                a[i] = a[i-1]
                a[i-1] = temp

mojesortowanie_old(slownik_old)
print(slownik_old)

slownik_modern =  ['samolot','samochod','marchewka','mecz','miecz','Mieczysław','Roman',
            'rolka','abakus','zenit','piorun','_a']

def mojesortowanie_modern(a):
    # for i,w in enumerate(slownik_old):
    #     slownik_old[i] = w.lower()
    for _ in range(len(a)):
        for i in range(1,len(a)):
            if a[i].lower() < a[i-1].lower():
                a[i-1],a[i] = a[i],a[i-1]

mojesortowanie_modern(slownik_modern)
print(slownik_modern)