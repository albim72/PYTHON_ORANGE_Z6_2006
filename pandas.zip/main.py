import numpy as np
import pandas as pd

s = pd.Series([1,2,4,np.nan,8,11])
print(s)

daty = pd.date_range("20220622",periods=6)
print(daty)

df = pd.DataFrame(np.random.randn(6,4),index=daty,columns=list("ABCD"))

print(df)

df.to_csv("dane.csv")