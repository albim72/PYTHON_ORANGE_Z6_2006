class IntFloatValueError(Exception):

    def __init__(self,value):
        self.value = value

    def __str__(self):
        return f'{self.value} jest wartością niewłaściwą. Słownik akceptuje tylko' \
               f'typy: int oraz float.'


class KeyValueConstructError(Exception):

    def __init__(self,key,value):
        self.key = key
        self.value = value

    def __str__(self):
        return f"klucze i wartości muszą zawierać się w krotkach lub listach! " \
               f"{self.key} jest typu: {type(self.key)}, " \
               f"{self.value} jest typu: {type(self.value)}"