#Stwórz słownik w oparciu o dwa zbiory: kluczy i wartości
#Napisz dwie klasy błędu: pierwsza do analizy typu wartości tego słownika,
# który przyjmuje tylko dwa wybory: int i float
#drugą do analizy rodzaju kolekcji poprzez które przekarzemy dane i klucze do słownika
#dopuszczalne typy to: krotka i lista
#tworząc słownik uwzględnij zbudowane klasy będów
#przeprowdź stosowne testy.

from dictionary import CustomIntFloatDict

test_1 = CustomIntFloatDict()
print(test_1)

# test_2 = CustomIntFloatDict({'a','b'},[34,767])
# print(test_2)
#
test_3 = CustomIntFloatDict(('x','y','z'),(10,'twenty',30))
print(test_3)

test_4 = CustomIntFloatDict(('x','y','z'),(10,20,30))
print(test_4)

test_5 = CustomIntFloatDict(('x','y','z'),(True,20,30))
print(test_5)