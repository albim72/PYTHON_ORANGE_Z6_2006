class SilniaError(Exception):

    def __init__(self,n):
        self.n = n

    def __str__(self):
        return f"wartość {self.n}, jest spoza zakresu dziedziny funkcji silnia. " \
               f"Silnia jest niezdefiniowana dla liczb ujemnych!"