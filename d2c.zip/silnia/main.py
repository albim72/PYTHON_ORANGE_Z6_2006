#silnia argumenty n -> naturalne
#n! = 1*2*...*n
#double -> max 1.8E+308
#n? max dbl 171
import sys
from mojewyjatki import SilniaError
def silnia(n):
    if n<0:
        raise SilniaError(n)

    wynik = 1
    for i in range(1,n+1):
        wynik *= i
    return wynik

def silnia_rek(n):
    if n < 0:
        raise SilniaError(n)

    if n==0:
        return 1
    else:
        return n*silnia_rek(n-1)


try:
    n = int(input("podaj argument n silnii (n>=0): "))
    print(f"silnia z n = {n} wynosi: {silnia(n)}")
    sys.setrecursionlimit(100000)
    print(f"silnia rekurencyjna z n = {n} wynosi: {silnia_rek(n)}")
    print(type(silnia(n)))
except SilniaError as d:
    print(d)
except:
    print("nienany błąd")
    raise
finally:
    print("spróbuj policzyć kolejny raz zadając wartość n >= 0")