import json

jsonosoba = '{"imie":"Janek","nazwisko":"Kot","wiek":23,"miasto":"Radom"}'
print(jsonosoba)
print(type(jsonosoba))

osoba = json.loads(jsonosoba)
print(osoba)
print(type(osoba))
print(osoba["miasto"])

pojazd = {
    "marka":"Opel",
    "model":"Insignia",
    "rok":2019,
    "poj":2.2
}

jsonauto = json.dumps(pojazd,indent=4)
print(jsonauto)
print(type(jsonauto))

with open("pojazd.json","w",encoding="utf-8") as f:
    f.write(jsonauto)

with open("pojazd.json","r",encoding="utf-8") as f:
    auto_dict = json.load(f)

print(auto_dict)
print(type(auto_dict))