class Singleton(type):

    _instances ={}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton,cls).__call__(*args, **kwargs)
        return cls._instances[cls]

class Regularna:
    pass

class SingletonClass(metaclass=Singleton):
    pass

rg1 = Regularna()
rg2 = Regularna()

print(rg1==rg2)

sg1 = SingletonClass()
sg2 = SingletonClass()

print(sg1==sg2)