import numpy as np
import matplotlib.pyplot as plotter
samplingFrequency = 100
samplingInterval = 1/samplingFrequency

beginTime = 0
endTime = 10

signal1Frequency = 4
signal2Frequency = 7
time = np.arange(beginTime,endTime,samplingInterval)
amplituda1 = np.sin(2*np.pi*signal1Frequency*time)
amplituda2 = np.sin(2*np.pi*signal2Frequency*time)
#Tworzenie wykresów

figure, axis = plotter.subplots(4,1)
plotter.subplots_adjust(hspace=1)
#kreślenie pierwszej funkcji aplituda1
axis[0].set_title('funkcja falowa o częstotliwości 4Hz')
axis[0].plot(time,amplituda1)
axis[0].set_xlabel('Czas')
axis[0].set_ylabel('Amplituda')
#kreślenie drugiej funkcji aplituda2
axis[1].set_title('funkcja falowa o częstotliwości 7Hz')
axis[1].plot(time,amplituda2)
axis[1].set_xlabel('Czas')
axis[1].set_ylabel('Amplituda')
#złożenie funckji falowych
amplituda = amplituda1 + amplituda2
#kreślenie złożenia dwóch funkcji falowych
axis[2].set_title('złożenie funkcji falowych o amplitudach 4 i 7 Hz')
axis[2].plot(time,amplituda)
axis[2].set_xlabel('Czas')
axis[2].set_ylabel('Amplituda')
#transformata Fouriera
#Normalizacja wartości funckji amplituda
fourierTransform = np.fft.fft(amplituda)/len(amplituda)
fourierTransform = fourierTransform[range(int(len(amplituda)/2))]
tpCount = len(amplituda)
values = np.arange(int(tpCount/2))
timePeriod = tpCount/samplingFrequency
frquencies = values/timePeriod
#kreślenie tranformaty Fouriera dla złożenia funkcji falowych
axis[3].set_title('Tranformata Fouriera dla wybranych częstoliwości')
axis[3].plot(frquencies,abs(fourierTransform))
axis[3].set_xlabel('Częstoliwość')
axis[3].set_ylabel('Amplituda')
plotter.show()
