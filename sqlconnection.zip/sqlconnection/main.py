import mysql.connector

db = mysql.connector.connect(user="root", password = "abc123", host="127.0.0.1",
                             port=3306, database = "dbtestowa")

cursorObject = db.cursor()
#cursorObject.execute("CREATE DATABASE IF NOT EXISTS dbtestowa")

table_student = "CREATE TABLE IF NOT EXISTS student(" \
                "id int not null primary key," \
                "imie varchar(30) not null," \
                "nazwisko varchar(30) not null," \
                "nralb int not null" \
                ")"

cursorObject.execute(table_student)

# sqlquery = "INSERT INTO student(id,imie,nazwisko,nralb) VALUES(%s,%s,%s,%s)"
# val = [
#     (1,"Jan","Kowal",345),
#     (2,"Janek","Kowal",567),
#     (3,"Anna","Kowal",347),
#     (4,"Olga","Kowal",123),
#     (5,"Olaf","Kowal",234),
#     (6,"Piotr","Kowal",789),
#     (7,"Henio","Kowal",987),
#     (8,"Kazio","Kowal",457),
#     (9,"Ola","Kowal",876)
# ]
# cursorObject.executemany(sqlquery,val)
# db.commit()
print(f"{cursorObject.rowcount} wierszy zostało wstawionych")

selquery = "SELECT * FROM student"
cursorObject.execute(selquery)
wynik = cursorObject.fetchall()

for x in wynik:
    print(x)

db.close()

