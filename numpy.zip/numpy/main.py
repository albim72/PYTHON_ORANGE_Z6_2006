import numpy as np

a = np.array([1,4,6,7,3,11,7,9,12,24])
print(a)

print(np.zeros(5))
print(np.ones(5))

print(np.arange(2,9,2))

print(np.linspace(0,10,num=5))

print(np.sort(a))

b = np.array([66,88,99,1001,56])

ab = np.concatenate((a,b),axis=0)
print(ab)

c = a.reshape(5,2)
print(c)

d = a.reshape(2,5)
print(d)